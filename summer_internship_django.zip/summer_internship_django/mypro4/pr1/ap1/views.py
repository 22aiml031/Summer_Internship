

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Item


    # Create your views here.
        
def home(request):
        return render(request, 'index.html')

def about(request):
        items = Item.objects.all()
        return render(request, 'about.html', {"items" : items} )

