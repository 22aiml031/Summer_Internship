from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Item
from .forms import EmployeeForm
from django.shortcuts import render,  get_object_or_404, redirect

    # Create your views here.
        
def home(request):
        return render(request, 'index.html')

def about(request):
        items = Item.objects.all()
        return render(request, 'about.html', {"items" : items} )

def employee(request):
        if request.method == "POST":
            form = EmployeeForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('home')
        else:
            form = EmployeeForm()        
        return render(request, 'employee.html')

def item_details(request, pk):
        item = Item.objects.get(id=pk)
        return render(request, 'item_details.html', {"item" : item} )