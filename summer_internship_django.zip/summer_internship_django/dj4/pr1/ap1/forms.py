from django.forms import forms
from .models import Product,User,Item


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'price', 'description']

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['user_name', 'user_email', 'user_password','user_phone']

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['item_name', 'item_img', 'item_des']