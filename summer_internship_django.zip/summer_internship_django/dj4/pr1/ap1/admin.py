from django.contrib import admin
from .models import Product,User,Item
# Register your models here.


class Productadmin(admin.ModelAdmin):
    pass


admin.site.register(Product, Productadmin)

class Useradmin(admin.ModelAdmin):
    pass

admin.site.register(User, Useradmin)

class Itemadmin(admin.ModelAdmin):
    pass

admin.site.register(Item, Itemadmin)