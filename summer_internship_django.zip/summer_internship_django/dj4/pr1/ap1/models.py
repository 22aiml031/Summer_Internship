from django.db import models

# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.FloatField()
    description = models.TextField()
    
class User(models.Model):
    user_name = models.CharField(max_length=15)
    user_email = models.EmailField()
    user_password = models.CharField(max_length=15)
    user_phone = models.IntegerField()

class Item(models.Model):
    item_name = models.CharField(max_length=10)
    item_img = models.ImageField(upload_to='item_images/', blank=True, null=True)
    item_des = models.TextField()

    def __str__(self):
        return self.item_name