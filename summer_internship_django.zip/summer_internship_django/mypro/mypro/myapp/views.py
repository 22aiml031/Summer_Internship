from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Item
from .forms import EmployeeForm

    # Create your views here.
        
def home(request):
        return render(request, 'index.html')

def about(request):
        items = Item.objects.all()
        return render(request, 'about.html', {"items" : items} )

def employee(request):
        if request.method == "POST":
            form = EmployeeForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('home')
        else:
            form = EmployeeForm()        
        return render(request, 'employee.html')