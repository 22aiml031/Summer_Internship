from django.db import models

# Create your models here.

class Product(models.Model):
    product_name = models.CharField(max_length=10)
    product_description = models.TextField()
    product_price = models.IntegerField()
     

class Item(models.Model):
    item_image = models.ImageField(upload_to = 'item_image', blank=True, null = True)
    item_title = models.CharField(max_length=10)
    item_des = models.TextField()   
    
    def __str__(self):
        return self.item_title  
    

class Employee(models.Model):
    first_name = models.CharField(max_length=10)
    last_name = models.CharField(max_length=10)
    email = models.EmailField()

    def __str__(self):
        return self.first_name + ' ' + self.last_name   