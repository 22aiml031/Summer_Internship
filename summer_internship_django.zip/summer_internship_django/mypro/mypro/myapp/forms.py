from django import forms
from .models import Product, Item, Employee

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['product_name', 'product_description', 'product_price']



class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['item_image', 'item_title', 'item_des']
        
        
class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['first_name', 'last_name', 'email']        