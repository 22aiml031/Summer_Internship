from django.shortcuts import render,redirect
from django.shortcuts import render,  get_object_or_404, redirect
from django.http import HttpResponse
from .forms import StudentForm,Item
from django.contrib.auth import authenticate,login as auth_login,logout as auth_logout
from django.contrib.auth.decorators import login_required
# Create your views here.

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def student(request):
        if request.method == "POST":
            form = StudentForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('home')
        else:
            form = StudentForm()        
        return render(request, 'student.html')

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('home')
        else:
            return HttpResponse("Invalid login")
    return render(request, 'login.html')
      
def logout(request):
    auth_logout(request)
    return redirect('home')

