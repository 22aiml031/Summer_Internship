

from django.shortcuts import render, redirect
from .forms import ContactForm
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


# Create your views here.

def home(request):
    return render(request, 'home.html')

def Products(request):
    if 'cart' not in request.session:
        request.session['cart'] = {}
    cart_count = sum(request.session['cart'].values())
    return render(request, 'Products.html', {'cart_count': cart_count})

def cart(request):
    cart = request.session.get('cart', {})
    return render(request, 'cart.html', {'cart': cart})

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})





