// Initialize cart array globally or retrieve from localStorage if it exists
let cart = JSON.parse(localStorage.getItem('cart')) || [];

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default anchor action
            const productId = this.getAttribute('data-product-id');
            cart.push(productId); // Add product ID to cart array
            // Save the updated cart to localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartButton(); // Update the View Cart button
        });
    });

    function updateCartButton() {
        const cartButton = document.getElementById('viewCartBtn');
        // Ensure cartButton exists and cart is defined
        if (cartButton && Array.isArray(cart)) {
            cartButton.textContent = `View Cart (${cart.length})`; // Update button text
        }
    }
});

// Call updateCartButton on page load to reflect current cart status
document.addEventListener('DOMContentLoaded', updateCartButton);