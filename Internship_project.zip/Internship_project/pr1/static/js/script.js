document.addEventListener('DOMContentLoaded', function() {
    const cartButton = document.getElementById('viewCartBtn');
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    // Initialize cartCount and cartItems to 0 and [] on every page load
    let cartCount = 0;
    let cartItems = [];

    // Update the cart button text on page load
    cartButton.textContent = `View Cart (${cartCount})`;

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            cartCount++;
            cartButton.textContent = `View Cart (${cartCount})`;

            const productId = this.getAttribute('data-product-id');
            const productTitle = this.closest('.card-body').querySelector('.card-title').textContent;
            const productPrice = this.closest('.card-body').querySelector('.card-text').textContent;
            // Assuming here you would add the product to cartItems and possibly update localStorage
        });
    });
});