document.addEventListener('DOMContentLoaded', function() {
    let cartItems = localStorage.getItem('cartItems') ? JSON.parse(localStorage.getItem('cartItems')) : [];

    function renderCartItems() {
        const cartItemsList = document.getElementById('cartItemsList');
        cartItemsList.innerHTML = ''; // Clear previous items
        let totalAmount = 0;
        
        cartItems.forEach((item, index) => {
            const total = item.quantity * parseFloat(item.price.replace('$', ''));
            totalAmount += total;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.title}</td>
                <td>${item.price}</td>
                <td>
                    <button class="btn btn-sm btn-secondary" onclick="updateQuantity(${index}, -1)">-</button>
                    ${item.quantity}
                    <button class="btn btn-sm btn-secondary" onclick="updateQuantity(${index}, 1)">+</button>
                </td>
                <td>$${total.toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="removeItem(${index})">Remove</button>
                </td>
            `;
            cartItemsList.appendChild(row);
        });

        const totalRow = document.createElement('tr');
        totalRow.innerHTML = `
            <td colspan="3" class="text-right"><strong>Total:</strong></td>
            <td colspan="2"><strong>$${totalAmount.toFixed(2)}</strong></td>
        `;
        cartItemsList.appendChild(totalRow);
    }

    window.updateQuantity = function(index, change) {
        cartItems[index].quantity += change;
        if (cartItems[index].quantity <= 0) {
            cartItems.splice(index, 1);
        }
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        renderCartItems();
    }

    window.removeItem = function(index) {
        cartItems.splice(index, 1);
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        renderCartItems();
    }

    renderCartItems();
});
// Inside your event listener for adding to cart
const productId = this.getAttribute('data-product-id');
fetch('/add-to-cart/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': csrftoken  // Assuming Django; ensure you have CSRF token handled
    },
    body: JSON.stringify({ productId: productId })
})
.then(response => response.json())
.then(data => console.log(data))
.catch((error) => console.error('Error:', error));